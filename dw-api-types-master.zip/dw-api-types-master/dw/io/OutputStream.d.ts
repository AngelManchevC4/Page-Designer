declare class OutputStream {
    /**
     * Closes the output stream.
     */
    close() : void
}

export = OutputStream;