declare class ObjectAttributeValueDefinition {
    displayValue: string;
    value: Object;

    getDisplayValue() : string;
    getValue() : Object;
}

export = ObjectAttributeValueDefinition;