

declare class ProductVariationAttribute {
    attributeID  :  string
    displayName  :  string
    ID  :  string
    getAttributeID() : string
    getDisplayName() : string
    getID() : string
}

export = ProductVariationAttribute