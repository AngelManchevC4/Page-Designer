

declare class CertificateRef {
    constructor(alias : string);
    tostring() : string;
}

export = CertificateRef;