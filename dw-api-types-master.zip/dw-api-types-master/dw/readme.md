folder contains type definition for dw objects
