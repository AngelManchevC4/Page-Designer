declare class PipelineDictionary {
    [key: string] : any
}
