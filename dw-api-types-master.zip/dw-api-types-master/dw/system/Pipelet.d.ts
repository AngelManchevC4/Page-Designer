

declare class Pipelet {

}

export = Pipelet;