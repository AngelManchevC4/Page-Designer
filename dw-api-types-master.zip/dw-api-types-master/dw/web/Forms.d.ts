import FormGroup = require('./FormGroup');

declare class Forms {
    [index: string] : FormGroup
}

export = Forms